import torch
import torch.nn as nn

class CNNBlockMultiFeature(nn.Module):
    def __init__(self, in_channels=3):  # Corrected to expect 3 input channels
        super(CNNBlockMultiFeature, self).__init__()
        # Three 1D Conv layers with BatchNorm and MaxPooling
        self.conv1 = nn.Conv1d(in_channels, 64, kernel_size=3, padding=1)  # Adjusted to 3 channels
        self.bn1 = nn.BatchNorm1d(64)
        self.pool1 = nn.MaxPool1d(kernel_size=2)

        self.conv2 = nn.Conv1d(64, 32, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(32)
        self.pool2 = nn.MaxPool1d(kernel_size=2)

        self.conv3 = nn.Conv1d(32, 64, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm1d(64)
        self.pool3 = nn.MaxPool1d(kernel_size=2)

    def forward(self, x):
        x = self.pool1(self.bn1(self.conv1(x)))
        x = self.pool2(self.bn2(self.conv2(x)))
        x = self.pool3(self.bn3(self.conv3(x)))
        return x

class AttentionMechanism(nn.Module):
    def __init__(self, input_dim):
        super(AttentionMechanism, self).__init__()
        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(input_dim, input_dim // 2)
        self.fc2 = nn.Linear(input_dim // 2, input_dim)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        attn_weights = self.global_avg_pool(x).squeeze(-1)
        attn_weights = torch.relu(self.fc1(attn_weights))
        attn_weights = self.sigmoid(self.fc2(attn_weights))
        attn_weights = attn_weights.unsqueeze(-1)
        return x * attn_weights

class ATT_CNN_GRU_MultiFeature(nn.Module):
    def __init__(self, in_channels=3, num_classes=16):  # Corrected to expect 3 input channels
        super(ATT_CNN_GRU_MultiFeature, self).__init__()

        # 1D CNN for feature extraction with multi-feature input
        self.cnn_block = CNNBlockMultiFeature(in_channels)

        # GRU for sequence learning
        self.gru = nn.GRU(64, 64, batch_first=True)

        # Attention Mechanism for feature fusion
        self.attention = AttentionMechanism(64)

        # Fully connected layers
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(8 * 64, 512)  # Adjust based on GRU output shape
        self.fc2 = nn.Linear(512, num_classes)

    def forward(self, x):
        # Input shape (batch_size, in_channels, seq_len)
        x = self.cnn_block(x)

        # GRU expects input shape (batch_size, seq_len, feature_dim)
        x = x.permute(0, 2, 1)
        x, _ = self.gru(x)

        # Permute back for attention
        x = x.permute(0, 2, 1)
        x = self.attention(x)

        x = self.flatten(x)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)

        return x
